Transients Manager
==================

Provides a UI to manage your site's transients. You can view, search, edit, and delete transients at will.
